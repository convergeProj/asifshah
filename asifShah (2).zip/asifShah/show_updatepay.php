<?php
error_reporting(0);
if (empty($_SESSION))// if the session not yet started
	session_start();

if (!isset($_SESSION['LOG_TYPE_SHOWROOM'])) {//if not yet logged in
	header("Location: index.php");
	// send to login page
	exit ;
}
?>
<!DOCTYPE html>
<html>
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>Asif Saha Boutique | Showroom</title>

		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
		<link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">

	</head>

	<body class="">

		<div id="wrapper">

			<?php include 'show_header.php'; ?>

			<div id="page-wrapper" class="gray-bg">
				<div class="row border-bottom">
					<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
						<div class="navbar-header">
							<a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
							<form role="search" class="navbar-form-custom" action="#">
								<div class="form-group">
									<input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
								</div>
							</form>
						</div>
						<ul class="nav navbar-top-links navbar-right">
							<li>
								<span class="m-r-sm text-muted welcome-message">Welcome to Asif Saha Boutique (Showroom)</span>
							</li>
							<li>
								<a href="logout.php"> <i class="fa fa-sign-out"></i> Log out </a>
							</li>
						</ul>

					</nav>
				</div>
				<div class="wrapper wrapper-content">
					<div class="row">
		                <div class="col-lg-12">
		                    <div class="ibox float-e-margins">
		                        <div class="ibox-title">
		                            <h5>Search your customer for updating payment</h5>
		                        </div>
		                        <div class="ibox-content">
		                            <form role="form" class="form-inline" method="post">
		                                <div class="form-group">
		                                    <label class="sr-only">Search by Name</label>
		                                    <input placeholder="Search by Name" class="form-control" type="text">
		                                </div>
		                                <div class="form-group">&nbsp;&nbsp;OR&nbsp;&nbsp;</div>
		                                <div class="form-group">
		                                    <label for="exampleInputPassword2" class="sr-only">Password</label>
		                                    <input placeholder="Search by Order Id" class="form-control" type="text" id="cid">
		                                </div>
		                                <div class="form-group">
		                                	<button style="margin-top: 5px;" class="btn btn-primary" type="submit" name="search">Search</button>
		                                </div>
		                                <div class="form-group">Search by <b>Customer Name</b> or <b>Order Id</b> via <b>Barcode Reader</b> or <b>Typing Manually</b></div>
		                            </form>
		                        </div>
		                    </div>
		                </div>
		        	</div>
		        	<?php
		        		if(isset($_POST['search'])){
		        			?>
		        			<div class="row">
				                <div class="col-lg-12">
				                    <div class="ibox float-e-margins">
				                        <div class="ibox-title">
				                            <h5>Search Result</h5>
				                        </div>
				                        <div class="ibox-content">
				                        	No data !
				                        </div>
				                    </div>
				                </div>
				            </div>
		        			<?php
		        		}
		        	?>            	
				</div>
				<div class="footer">
					<div>
						<strong>Copyright</strong> Asif Saha Boutique &copy; 2016-2017
					</div>
				</div>

			</div>
		</div>

		<!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/plugins/jeditable/jquery.jeditable.js"></script>

    <script src="js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

            /* Init DataTables */
            var oTable = $('#editable').DataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( 'http://webapplayers.com/example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            });
        });

        function fnClickAddRow() {
            $('#editable').dataTable().fnAddData( [
                "Custom row",
                "New row",
                "New row",
                "New row",
                "New row" ] );

        }
    </script>
	<script>
		document.getElementById("cid").focus();
	</script>
	</body>
</html>
