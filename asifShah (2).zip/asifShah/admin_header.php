<?php $page = basename($_SERVER['PHP_SELF']); /* Returns The Current PHP File Name */ ?>
<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#"> <span class="clear" style="font-size: 14px;"> <span class="block m-t-xs"> <strong class="font-bold">Asif Saha Boutique</strong></span> <span class="text-muted text-xs block">Administrator</span> </span> </a>
                </div>
                <div class="logo-element">
                    ASIF
                </div>
            </li>
            <li <?php if($page=='admin_welcome.php'){ ?> class="active" <?php } ?>>
                <a href="admin_welcome.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
            </li>
            <li <?php if($page=='admin_showroom.php'){ ?> class="active" <?php } ?>>
                <a href="admin_showroom.php"><i class="fa fa-image"></i> <span class="nav-label">Showroom</span></a>
            </li>
            <li <?php if($page=='admin_warehouse.php'){ ?> class="active" <?php } ?>>
                <a href="admin_warehouse.php"><i class="fa fa-building"></i> <span class="nav-label">Warehouse</span></a>
            </li>
            <li <?php if($page=='admin_workshop.php'){ ?> class="active" <?php } ?>>
                <a href="admin_workshop.php"><i class="fa fa-users"></i> <span class="nav-label">Workshop</span></a>
            </li>
            <li <?php if($page=='admin_alteration.php'){ ?> class="active" <?php } ?>>
                <a href="admin_alteration.php"><i class="fa fa-recycle"></i> <span class="nav-label">Alteration</span></a>
            </li>
        </ul>

    </div>
</nav>