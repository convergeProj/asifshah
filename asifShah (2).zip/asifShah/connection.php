<?PHP

    //$SERVER_HOST = "localhost";
    //$SERVER_USER = "cnvg_asifshah";
    //$SERVER_PASSWORD = "@asifshah@123";
    //$SERVER_DATABASE = "cnvg_asifcollection";
	
    $SERVER_HOST = "localhost";
    $SERVER_USER = "root";
    $SERVER_PASSWORD = "";
    $SERVER_DATABASE = "asif";

    $CONN = mysql_connect($SERVER_HOST, $SERVER_USER, $SERVER_PASSWORD) or die("SERVER CONNECTION FAILED : " . mysql_error());
    mysql_select_db($SERVER_DATABASE, $CONN) or die("SERVER DATABASE CONNECTION FAILED : " . mysql_error());
	
?>	
