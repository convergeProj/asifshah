<?php
        session_start();
	include 'connection.php';
	
	require_once "recaptchalib.php";
	
	// your secret key
	$secret = "6Le7OhsTAAAAALD5J0Ah_fWimipvBkQ04ViMhHTJ";
	 
	// empty response
	$response = null;
	 
	// check secret key
	$reCaptcha = new ReCaptcha($secret);
	

	// if submitted check response
	if ($_POST["g-recaptcha-response"]) {
	    $response = $reCaptcha->verifyResponse(
	        $_SERVER["REMOTE_ADDR"],
	        $_POST["g-recaptcha-response"]
	    );
	}
	
	
	if ($response != null && $response->success) {
	    	$uname = $_REQUEST['uname'];
		$pass = $_REQUEST['pass'];
		//echo "SELECT * FROM logtbl WHERE uname='$uname' AND passwd='$pass'";
		$rs = mysql_query("SELECT * FROM logtbl WHERE uname='$uname' AND passwd='$pass'");
		if(mysql_num_rows($rs)){
			$data = mysql_fetch_array($rs);
			//echo $data['log_type'];
			if($data['log_type'] == 'admin'){
				$_SESSION['LOG_TYPE'] = $data['uname'];
				?> <script> window.location.href='admin_welcome.php' </script> <?php
			}else if($data['log_type'] == 'showroom'){
				
				$_SESSION['LOG_TYPE_SHOWROOM'] = $data['uname'];
				?> <script> window.location.href='showroom_welcome.php' </script> <?php
			}else if($data['log_type'] == 'warehouse'){
				
				$_SESSION['LOG_TYPE_WAREHOUSE'] = $data['uname'];
				?> <script> window.location.href='warehouse_admin.php' </script> <?php
			}else{
				?> <script> window.location.href='index.php' </script> <?php
			}
		}else{
			?> <script> window.location.href='index.php' </script> <?php
		}
	}else{
		?> <script> window.location.href='index.php?captchaError' </script> <?php
	}

?>