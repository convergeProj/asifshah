<?php
	session_start();
	unset($_SESSION['LOG_TYPE']);
	unset($_SESSION['LOG_TYPE_SHOWROOM']);
	
	session_destroy();

	header("Location: index.php");
	exit;
?>
