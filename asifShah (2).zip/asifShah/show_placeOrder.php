<?php
error_reporting(0);
if (empty($_SESSION))// if the session not yet started
    session_start();
if (!isset($_SESSION['LOG_TYPE_SHOWROOM'])) {//if not yet logged in
    header("Location: index.php");
    // send to login page
    exit;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Asif Saha Boutique | Showroom</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
		<link href="css/plugins/iCheck/custom.css" rel="stylesheet">
		<link href="css/plugins/chosen/chosen.css" rel="stylesheet">
		<link href="css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
		<link href="css/plugins/cropper/cropper.min.css" rel="stylesheet">
		<link href="css/plugins/switchery/switchery.css" rel="stylesheet">
		<link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
		<link href="css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">
		<link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">
		<link href="css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
		<link href="css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">
		<link href="css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
		<link href="css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
		<link href="css/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet">
		<link href="css/plugins/select2/select2.min.css" rel="stylesheet">
		<link href="css/plugins/touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
        <style>
            .control-label{
                font-weight: normal;
                font-size: 14px;
            }
        </style>
        <?php

        function generateBarCode($number) {
            $prefix = "1"; // update the prefix here

            $unique = str_pad($number, 3, "0", STR_PAD_LEFT);
            $unique = $prefix . $unique;

            $result = '';
            $length = 8;
            for ($i = 0; $i < $length; $i++) {
                $result .= mt_rand(0, 9);
            }
            return $result . $unique;
        }
        ?>
		<SCRIPT language="javascript">
           function addRow(tableID) {
 
            var table = document.getElementById(tableID);
 
            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);
 
            
 
            var cell1 = row.insertCell(0);
            var element1 = document.createElement("input");
            element1.type = "checkbox";
			element1.className = "iCheck-helper";
            element1.name="chkbox[]";
            cell1.appendChild(element1);
			
			var cell2 = row.insertCell(1);
            var element2 = document.createElement("input");
            element2.type = "text";
            element2.name = "desc[]";
			element2.className = "form-control";
            cell2.appendChild(element2);
 
            var cell3 = row.insertCell(2);
            var element3 = document.createElement("input");
            element3.type = "text";
            element3.name = "qty[]";
			element3.className = "form-control";
            cell3.appendChild(element3);
			
			var cell4 = row.insertCell(3);
            var element4 = document.createElement("input");
            element4.type = "text";
            element4.name = "rate[]";
			element4.className = "form-control";
            cell4.appendChild(element4);
			
			var cell5 = row.insertCell(4);
            var element5 = document.createElement("input");
            element5.type = "text";
            element5.name = "amt[]";
			element5.className = "form-control";
            cell5.appendChild(element5);
        }
 
        function deleteRow(tableID) {
            try {
            var table = document.getElementById(tableID);
            var rowCount = table.rows.length;
 
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    table.deleteRow(i);
                    rowCount--;
                    i--;
                }
            }
            }catch(e) {
                alert(e);
            }
        }
 
    </SCRIPT>
    </head>
    <body class="">
        <div id="wrapper">
            <?php include 'show_header.php'; ?>
			  <?php include 'connection.php'; ?>
            <div id="page-wrapper" class="gray-bg">
                <div class="row border-bottom">
                    <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                        <div class="navbar-header">
                            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                            <form role="search" class="navbar-form-custom" action="#">
                                <div class="form-group">
                                    <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
                                </div>
                            </form>
                        </div>
                        <ul class="nav navbar-top-links navbar-right">
                            <li>
                                <span class="m-r-sm text-muted welcome-message">Welcome to Asif Saha Boutique (Showroom)</span>
                            </li>
                            <li>
                                <a href="logout.php"> <i class="fa fa-sign-out"></i> Log out </a>
                            </li>
                        </ul>

                    </nav>
                </div>
                <?php
                    $num = "1";
                    $code = generateBarCode($num);
                ?>
                <div class="wrapper wrapper-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox">
                                <div class="ibox-title">
                                    <h5>Place New Order Here</h5>
                                    <h5 class="pull-right">ORDER ID : <b><?= $code ?></b></h5>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form  class="form-horizontal" method="post">
                                                <div class="form-group">
                                                    <div class="col-sm-2">
                                                        <label class="checkbox-inline i-checks"> 
                                                            <label class="checkbox-inline i-checks"> 
                                                                <input checked="" name="pay" type="radio" value="cash"> Cash
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="col-sm-7">
                                                        <label class="checkbox-inline i-checks"> 
                                                            <label class="checkbox-inline i-checks"> 
                                                                <input name="pay" type="radio" value="credit"> Credit 
                                                            </label>
                                                        </label>    
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <img src="barcode.php?code=<?= $code ?>" width="230px;">
                                                        <input type="hidden" value="<?= $code ?>" name="cl_code">
                                                    </div>
                                                </div>
                                                <div class="hr-line-dashed"></div>
                                                <div class="form-group">
                                                    <div class="col-sm-3">
                                                        <label>Order Date <span style="color: #f00">*</span></label>
                                                        <div id="data_1">
                                                            <div class="input-group date">
                                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input name="order_date" required="" type="text" class="form-control" value="<?=date('d M, Y')?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label>Trial Date <span style="color: #f00">*</span></label>
                                                        <div id="data_1">
                                                            <div class="input-group date">
                                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input name="trial_date" required="" type="text" class="form-control" value="<?=date('d M, Y')?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label>Delivery Date <span style="color: #f00">*</span></label>
                                                        <div id="data_1">
                                                            <div class="input-group date">
                                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input name="delivery_date" required="" type="text" class="form-control" value="<?=date('d M, Y')?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <label>Select Entry Type <span style="color: #f00">*</span></label>
                                                        <select required="" name="entrytype" class="form-control" name="account" />
                                                            <option value="">Entry Type</option>
                                                            <option value="jobworker">Job Worker</option>
                                                            <option value="readymade">Readymade</option>
                                                            <option value="fax">Send Fax</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Customer Name <span style="color: #f00">*</span></label>
                                                    <div class="col-sm-4"><input name="customername" required="" class="form-control" type="text"></div>
                                                    <label class="col-sm-2 control-label">Mobile <span style="color: #f00">*</span></label>
                                                    <div class="col-sm-4">
                                                        <input name="contact" type="text" class="form-control" data-mask="(999) 999-9999" placeholder="">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Complete Address</label>

                                                    <div class="col-sm-4"><input name="address" class="form-control" type="text"></div>
                                                    <label class="col-sm-2 control-label">Remarks</label>
 
                                                    <div class="col-sm-4"><input class="form-control" name="remark" type="text"></div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <table class="table table-bordered" id="dataTable">
                                                            <thead>
                                                                <tr>
                                                                    <th>Sr.</th>
                                                                    <th>Item Description</th>
                                                                    <th>Quantity</th>
                                                                    <th>Rate</th>
                                                                    <th>Amount</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td><input class="form-control"  name="desc[]" type="text"></td>
                                                                    <td><input class="form-control" name="qty[]" type="text"></td>
                                                                    <td><input class="form-control"  name="rate[]" type="text"></td>
                                                                    <td><input class="form-control"  name="amt[]" type="text"></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
												<div class="text-right">
													 <button class="btn btn-warning" type="button" onclick="addRow('dataTable')"><i class="fa fa-plus"></i>
					</button>
													 <button class="btn btn-danger" type="button" onclick="deleteRow('dataTable')"><i class="fa fa-times"></i>
					</button>
													
												 </div>
												 </br> 
                                                <div class="form-group">
                                                    <div class="col-sm-3">
                                                        <input placeholder="Advance (Rs.)" class="form-control" type="text" name="advance">
                                                    </div>

                                                    <div class="col-sm-3"><input placeholder="Balance (Rs.)" class="form-control" type="text" name="balance"></div>
                                                    <div class="col-sm-3">
                                                        <select class="form-control" name="account">
                                                            <option value="">Salesman</option>
                                                            <option value="akibkhan">Akib Khan</option>
                                                        </select>
                                                    </div>
													 <div class="col-sm-3">
                                                        <input type="submit" name="orderPLAce" class="btn btn-primary" value="Order Here" />
														
                                                    </div>
                                                </div>	
                                              
                                            </form>
                                        </div>

                                    </div>		   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer">
                    <div>
                        <strong>Copyright</strong> Asif Saha Boutique &copy; 2016-2017
                    </div>
                </div>
            </div>
        </div>
<?php
if(isset($_POST['orderPLAce'])){
	$pay = $_POST['pay'];
	$cl_code = $_POST['cl_code'];
	$order_date = $_POST['order_date'];
	$trial_date = $_POST['trial_date'];
	$delivery_date = $_POST['delivery_date'];
	$entrytype = $_POST['entrytype'];
	$customername = $_POST['customername'];
	$contact = $_POST['contact'];
	$address = $_POST['address'];
	$remark = $_POST['remark'];
	$total_qty = $_POST['total_qty'];
	$total_amt = $_POST['total_amt'];
	$advance = $_POST['advance'];
	$balance = $_POST['balance'];
	$account = $_POST['account'];
	$sql = mysql_query("INSERT INTO ordertbl (acc_customername, acc_address, cash, acc_orderno, acc_remark, acc_trialdate, acc_deliverydate, acc_orderdate, totalamount, assignworker, acc_phone, entry_type, total_qty, advance, balance) VALUES ('$customername', '$address', '$pay', '$cl_code', '$remark', '$trial_date', '$delivery_date', '$order_date', '$total_amt', '$account', '$contact', '$entrytype', '$total_qty', '$advance', '$balance')");
	$last_id = mysql_insert_id($CONN);
	$desc = $_POST['desc'];
	$qty = $_POST['qty'];
	$rate = $_POST['rate'];
	$amt = $_POST['amt'];
	$i = 0;
		foreach($desc as $value){
            $dess = $value;
			$qtyy = $qty[$i];
			$ratt = $rate[$i];
			$amtt = $amt[$i];
			$i++;
			mysql_query("INSERT INTO order_item (oid, item_desc, item_qty, item_rate, item_amt) VALUES ('$last_id', '$dess', '$qtyy', '$ratt', '$amtt' )");
         } ?>
		<script>window.location.href="show_placeOrder.php?success";</script> 
<?php }

 ?>
        <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Chosen -->
    <script src="js/plugins/chosen/chosen.jquery.js"></script>

   <!-- JSKnob -->
   <script src="js/plugins/jsKnob/jquery.knob.js"></script>

   <!-- Input Mask-->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

   <!-- Data picker -->
   <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

   <!-- NouSlider -->
   <script src="js/plugins/nouslider/jquery.nouislider.min.js"></script>

   <!-- Switchery -->
   <script src="js/plugins/switchery/switchery.js"></script>

    <!-- IonRangeSlider -->
    <script src="js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

    <!-- iCheck -->
    <script src="js/plugins/iCheck/icheck.min.js"></script>

    <!-- MENU -->
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Color picker -->
    <script src="js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

    <!-- Clock picker -->
    <script src="js/plugins/clockpicker/clockpicker.js"></script>

    <!-- Image cropper -->
    <script src="js/plugins/cropper/cropper.min.js"></script>

    <!-- Date range use moment.js same as full calendar plugin -->
    <script src="js/plugins/fullcalendar/moment.min.js"></script>
    <script src="js/plugins/daterangepicker/daterangepicker.js"></script>
    <script src="js/plugins/select2/select2.full.min.js"></script>
    <script src="js/plugins/touchspin/jquery.bootstrap-touchspin.min.js"></script>
    <script>
        $(document).ready(function(){

            var $image = $(".image-crop > img")
            $($image).cropper({
                aspectRatio: 1.618,
                preview: ".img-preview",
                done: function(data) {
                    // Output the result data for cropping image.
                }
            });

            var $inputImage = $("#inputImage");
            if (window.FileReader) {
                $inputImage.change(function() {
                    var fileReader = new FileReader(),
                            files = this.files,
                            file;

                    if (!files.length) {
                        return;
                    }

                    file = files[0];

                    if (/^image\/\w+$/.test(file.type)) {
                        fileReader.readAsDataURL(file);
                        fileReader.onload = function () {
                            $inputImage.val("");
                            $image.cropper("reset", true).cropper("replace", this.result);
                        };
                    } else {
                        showMessage("Please choose an image file.");
                    }
                });
            } else {
                $inputImage.addClass("hide");
            }

            $("#download").click(function() {
                window.open($image.cropper("getDataURL"));
            });

            $("#zoomIn").click(function() {
                $image.cropper("zoom", 0.1);
            });

            $("#zoomOut").click(function() {
                $image.cropper("zoom", -0.1);
            });

            $("#rotateLeft").click(function() {
                $image.cropper("rotate", 45);
            });

            $("#rotateRight").click(function() {
                $image.cropper("rotate", -45);
            });

            $("#setDrag").click(function() {
                $image.cropper("setDragMode", "crop");
            });

            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                format: "dd M, yyyy",
                startDate: new Date()
            });

            $('#data_2 .input-group.date').datepicker({
                startView: 1,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $('#data_3 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_4 .input-group.date').datepicker({
                minViewMode: 1,
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                todayHighlight: true
            });

            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            var elem = document.querySelector('.js-switch');
            var switchery = new Switchery(elem, { color: '#1AB394' });

            var elem_2 = document.querySelector('.js-switch_2');
            var switchery_2 = new Switchery(elem_2, { color: '#ED5565' });

            var elem_3 = document.querySelector('.js-switch_3');
            var switchery_3 = new Switchery(elem_3, { color: '#1AB394' });

            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green'
            });

            $('.demo1').colorpicker();

            var divStyle = $('.back-change')[0].style;
            $('#demo_apidemo').colorpicker({
                color: divStyle.backgroundColor
            }).on('changeColor', function(ev) {
                        divStyle.backgroundColor = ev.color.toHex();
                    });

            $('.clockpicker').clockpicker();

            $('input[name="daterange"]').daterangepicker();

            $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));

            $('#reportrange').daterangepicker({
                format: 'MM/DD/YYYY',
                startDate: moment().subtract(29, 'days'),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '12/31/2015',
                dateLimit: { days: 60 },
                showDropdowns: true,
                showWeekNumbers: true,
                timePicker: false,
                timePickerIncrement: 1,
                timePicker12Hour: true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                opens: 'right',
                drops: 'down',
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-primary',
                cancelClass: 'btn-default',
                separator: ' to ',
                locale: {
                    applyLabel: 'Submit',
                    cancelLabel: 'Cancel',
                    fromLabel: 'From',
                    toLabel: 'To',
                    customRangeLabel: 'Custom',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
                    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                    firstDay: 1
                }
            }, function(start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            });

            $(".select2_demo_1").select2();
            $(".select2_demo_2").select2();
            $(".select2_demo_3").select2({
                placeholder: "Select a state",
                allowClear: true
            });


            $(".touchspin1").TouchSpin({
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin2").TouchSpin({
                min: 0,
                max: 100,
                step: 0.1,
                decimals: 2,
                boostat: 5,
                maxboostedstep: 10,
                postfix: '%',
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin3").TouchSpin({
                verticalbuttons: true,
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });


        });
        var config = {
                '.chosen-select'           : {},
                '.chosen-select-deselect'  : {allow_single_deselect:true},
                '.chosen-select-no-single' : {disable_search_threshold:10},
                '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
                '.chosen-select-width'     : {width:"95%"}
                }
            for (var selector in config) {
                $(selector).chosen(config[selector]);
            }

        $("#ionrange_1").ionRangeSlider({
            min: 0,
            max: 5000,
            type: 'double',
            prefix: "$",
            maxPostfix: "+",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_2").ionRangeSlider({
            min: 0,
            max: 10,
            type: 'single',
            step: 0.1,
            postfix: " carats",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_3").ionRangeSlider({
            min: -50,
            max: 50,
            from: 0,
            postfix: "°",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_4").ionRangeSlider({
            values: [
                "January", "February", "March",
                "April", "May", "June",
                "July", "August", "September",
                "October", "November", "December"
            ],
            type: 'single',
            hasGrid: true
        });

        $("#ionrange_5").ionRangeSlider({
            min: 10000,
            max: 100000,
            step: 100,
            postfix: " km",
            from: 55000,
            hideMinMax: true,
            hideFromTo: false
        });

        $(".dial").knob();

        $("#basic_slider").noUiSlider({
            start: 40,
            behaviour: 'tap',
            connect: 'upper',
            range: {
                'min':  20,
                'max':  80
            }
        });

        $("#range_slider").noUiSlider({
            start: [ 40, 60 ],
            behaviour: 'drag',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });

        $("#drag-fixed").noUiSlider({
            start: [ 40, 60 ],
            behaviour: 'drag-fixed',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });
    </script>
    </body>
</html>
