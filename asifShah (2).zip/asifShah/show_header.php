<?php
	$page = basename($_SERVER['PHP_SELF']); /* Returns The Current PHP File Name */
?>
<nav class="navbar-default navbar-static-side" role="navigation">
	<div class="sidebar-collapse">
		<ul class="nav metismenu" id="side-menu">
			<li class="nav-header">
				<div class="dropdown profile-element">
					<a data-toggle="dropdown" class="dropdown-toggle" href="#"> <span class="clear" style="font-size: 14px;"> <span class="block m-t-xs"> <strong class="font-bold">Asif Saha Boutique</strong></span> <span class="text-muted text-xs block">Showroom</span> </span> </a>
				</div>
				<div class="logo-element">
					ASIF
				</div>
			</li>
			<li <?php if($page == "showroom_welcome.php"){ ?> class="active" <?php } ?> >
				<a href="showroom_welcome.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
			</li>
			<li <?php if($page == "show_placeOrder.php"){ ?> class="active" <?php } ?>>
				<a href="show_placeOrder.php"><i class="fa fa-bars"></i> <span class="nav-label">Place Order</span></a>
			</li>
			<li <?php if($page == "show_alteration.php"){ ?> class="active" <?php } ?>>
				<a href="show_alteration.php"><i class="fa fa-reply"></i> <span class="nav-label">Send to Alteration</span></a>
			</li>
			<li <?php if($page == "show_updatepay.php"){ ?> class="active" <?php } ?>>
				<a href="show_updatepay.php"><i class="fa fa-circle-o-notch"></i> <span class="nav-label">Update Payment</span></a>
			</li>
		</ul>

	</div>
</nav>