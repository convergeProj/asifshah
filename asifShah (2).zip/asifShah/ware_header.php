<?php $page = basename($_SERVER['PHP_SELF']); /* Returns The Current PHP File Name */ ?>
<nav class="navbar-default navbar-static-side" role="navigation">
	<div class="sidebar-collapse">
		<ul class="nav metismenu" id="side-menu">
			<li class="nav-header">
				<div class="dropdown profile-element">
					<a data-toggle="dropdown" class="dropdown-toggle" href="#"> <span class="clear" style="font-size: 14px;"> <span class="block m-t-xs"> <strong class="font-bold">Asif Saha Boutique</strong></span> <span class="text-muted text-xs block">Warehouse</span> </span> </a>
				</div>
				<div class="logo-element">
					ASIF
				</div>
			</li>
			<li <?php if($page == "warehouse_admin.php"){ ?> class="active" <?php } ?> >
				<a href="warehouse_admin.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
			</li>
			<li <?php if($page == "warehouse_clothes.php"){ ?> class="active" <?php } ?>>
				<a href="warehouse_clothes.php"><i class="fa fa-plus"></i> <span class="nav-label">Add Clothes</span></a>
			</li>
		</ul>
	</div>
</nav>